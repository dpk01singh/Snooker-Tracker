package com.android.emmatranter.snooker_tracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class IntroActivity extends Activity
{
    public Button StartGame;
    public EditText Player1_team1 ,Player2_team1 ,Player1_team2, Player2_team2;
    public  Intent intent;
    String name1,name2,name3,name4;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_activity);
        StartGame = (Button)findViewById(R.id.StartGame);
        Player1_team1 = (EditText)findViewById(R.id.editText1);
        Player2_team1 = (EditText)findViewById(R.id.editText2);
        Player1_team2 = (EditText)findViewById(R.id.editText3);
        Player2_team2 =  (EditText)findViewById(R.id.editText4);
        intent = new Intent(this , GameActivityClass.class);
        name1 = Player1_team1.getText().toString();
        name2 = Player2_team1.getText().toString();
        name3 = Player1_team2.getText().toString();
        name4 = Player2_team2.getText().toString();

        click();
    }
   public  void click()
    {
        StartGame.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {

                // this is the code that is going to check that if the user has not entered the name then the app will not start
                if ( name1 == null )
                {
                    if ( name3 == null  && name4 == null)
                    {
                        Toast.makeText(getApplicationContext(), " Enter All players name ", Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    Toast.makeText( getApplicationContext()," Welcome to the Game ",Toast.LENGTH_LONG).show();
                    intent.putExtra("a",Player1_team1.getText().toString());
                    intent.putExtra("b",Player2_team1.getText().toString());
                    intent.putExtra("c",Player1_team2.getText().toString());
                    intent.putExtra("d",Player2_team2.getText().toString());

                    startActivity(intent);
                }

            }
        });

    }
}
