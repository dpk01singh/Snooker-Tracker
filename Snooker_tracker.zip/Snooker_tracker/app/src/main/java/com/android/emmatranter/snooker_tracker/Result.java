package com.android.emmatranter.snooker_tracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Result extends Activity
{
    public Button play_again;
    public TextView playername ,playerscore, team, teamscore;
    public Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_activity);
        play_again =(Button)findViewById(R.id.playagain);
        playername = (TextView)findViewById(R.id.nameofplayer);
        playerscore = (TextView)findViewById(R.id.scoreofplayer);
        team = (TextView)findViewById(R.id.nameofteam);
        teamscore =(TextView)findViewById(R.id.scoreofteam);
       if (getIntent() != null)
        {
            String team_name = getIntent().getStringExtra("team");

            String team_score = getIntent().getStringExtra("team_score");
            String player_name = getIntent().getStringExtra("player_name");
            String player_score = getIntent().getStringExtra("player_score");
            // Putting the above data into the TextView of the Result Activity
            team.setText(team_name);
            teamscore.setText(team_score);
            playername.setText(player_name);
            playerscore.setText(player_score);
        }
        else
        {
            Toast.makeText(this , "Nothing Found ",Toast.LENGTH_LONG).show();
        }
       /* if ( getIntent() !=  null)
        {
            if (getIntent().getStringExtra("team_score") == null)
            {
                Toast.makeText(this , " Nothing found in the Team Score  ",Toast.LENGTH_LONG).show();
            }
             else if (getIntent().getStringExtra("player_score" ) == null)
            {
                Toast.makeText(this , " Nothing found in the player Score  ",Toast.LENGTH_LONG).show();
            }

        }*/




        intent = new Intent(this,IntroActivity.class);
        goto_main();

    }
    public void goto_main()
    {
        play_again.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                startActivity(intent);
            }
        });
    }
}
