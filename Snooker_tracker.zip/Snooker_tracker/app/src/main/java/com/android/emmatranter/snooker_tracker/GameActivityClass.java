package com.android.emmatranter.snooker_tracker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class GameActivityClass extends Activity
{
    public Button red,blue,green,brown,black,yellow,pink,foul,next_plr,finish,clear;
    public TextView team1_score, team1_palyer1_name, team1_player2_name, team1_player1_score, team1_player2_score;
    public TextView team2_score ,team2_player1_name, team2_player2_name , team2_player1_score, team2_player2_score, player_number;
    public Intent intent;
    int plrnumber =1,score_team1 =0, score_P1T1 =0, score_P2T1 =0,score_team2 = 0, score_P1T2 =0,score_P2T2 =0;
    int red_ball = 0,blue_ball=0,green_ball=0,brown_ball=0,pink_ball=0,yellow_ball=0,black_ball=0,red_ball_counter =0;
    String name1,name2,name3,name4;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_activity);


        // these are the Buttons on the Game Activity
        red = (Button)findViewById(R.id.red);
        blue =(Button)findViewById(R.id.Blue);
        black = (Button)findViewById(R.id.black);
        brown = (Button)findViewById(R.id.brown);
        yellow =(Button)findViewById(R.id.yellow);
        pink =(Button)findViewById(R.id.pink);
        green =(Button)findViewById(R.id.green);
        foul = (Button)findViewById(R.id.foul);
        next_plr =(Button)findViewById(R.id.nextplayer);
        finish = (Button)findViewById(R.id.finish);
        clear = (Button)findViewById(R.id.clear);
        // These are the Text Views on the Game Activity
        team1_score = (TextView)findViewById(R.id.t1s);
        team1_palyer1_name = (TextView)findViewById(R.id.t1p1n);
        team1_player1_score = (TextView)findViewById(R.id.t1p1s);
        team1_player2_name = (TextView)findViewById(R.id.t1p2n);
        team1_player2_score =(TextView)findViewById(R.id.t1p2s);
        team2_score = (TextView)findViewById(R.id.t2s);
        team2_player1_name = (TextView)findViewById(R.id.t2p1n);
        team2_player1_score = (TextView)findViewById(R.id.t2p1s);
        team2_player2_name = (TextView)findViewById(R.id.t2p2n);
        team2_player2_score = (TextView)findViewById(R.id.t2p2s);
        player_number = (TextView)findViewById(R.id.playernumber);


        // Below are the values from the first Activity i stored them in name1 name2 name3 name4 of String variable ( Names of the Players )
        if (getIntent()!= null)
        {
            name1 = getIntent().getStringExtra("a");
            name2 = getIntent().getStringExtra("b");
            name3 = getIntent().getStringExtra("c");
            name4 = getIntent().getStringExtra("d");
            team1_palyer1_name.setText(name1);
            team1_player2_name.setText(name2);
            team2_player1_name.setText(name3);
            team2_player2_name.setText(name4);
        }
        else
        {
            Toast.makeText(this ," Nothing Recived",Toast.LENGTH_LONG).show();
        }


        // this is intent for the final Activity
        intent = new Intent(this ,Result.class);


       // All the Function Calling is Below and Their Decleration is outside the class
        finishh();red();blue();black();brown();green();yellow();pink();foul();nextplayer();clear();
    }
    public void Game_Over()
    {
        Toast.makeText(this,"Game Is Over No more Ball Left!!!",Toast.LENGTH_SHORT).show();
    }

    public void HighScore()
    {
        if (score_team1 > score_team2)
        {
            if (score_P1T1 > score_P1T2)
            {   intent.putExtra("team","Team 1");
                intent.putExtra("team_score",String.valueOf(score_team1));
                intent.putExtra("player_name",name1);
                intent.putExtra("player_score",String.valueOf(score_P1T1));
                startActivity(intent);
            }
            else
            {

                intent.putExtra("team","Team 1");
                intent.putExtra("team_score",String.valueOf(score_team1));
                intent.putExtra("player_name",name2);
                intent.putExtra("player_score",String.valueOf(score_P2T1));
                startActivity(intent);
            }
        }
        else if ( score_team2 > score_team1)
        {
            if (score_P1T2 > score_P2T2)
            {
                intent.putExtra("team","Team 2");
                intent.putExtra("team_score",String.valueOf(score_team2));
                intent.putExtra("player_name",name3);
                intent.putExtra("player_score",String.valueOf(score_P1T2));
                startActivity(intent);
            }
            else
            {
                intent.putExtra("team","Team 2");
                intent.putExtra("team_score",String.valueOf(score_team2));
                intent.putExtra("player_name",name4);
                intent.putExtra("player_score",String.valueOf(score_P2T2));
                startActivity(intent);
            }
        }
        else  if (score_team2 == score_team1)
        {
            // here don't worry about the name m using in the putExtra mrthod it is just to send the message that both team has the same score
            intent.putExtra("team_name",score_team2);
            intent.putExtra("player_name",score_team2);
            startActivity(intent);
        }
    }
    public void finishh()
    {
        finish.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                HighScore();

            }
        });
    }
    public void clear()
    {
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                score_team1 =0; score_P1T1 =0; score_P2T1 =0;score_team2 = 0; score_P1T2 =0;score_P2T2 =0;
                red_ball = 0;blue_ball=0;green_ball=0;brown_ball=0;pink_ball=0;yellow_ball=0;black_ball=0;red_ball_counter =0;
                team1_player1_score.setText(String.valueOf(score_P1T1));
                team1_player2_score.setText(String.valueOf(score_P2T1));
                team2_player1_score.setText(String.valueOf(score_P1T2));
                team2_player2_score.setText(String.valueOf(score_P2T2));
                team1_score.setText(String.valueOf(score_team1));
                team2_score.setText(String.valueOf(score_team2 ));

            }
        });
    }
     public void red()
     {
         red.setOnClickListener(new View.OnClickListener()
         {
             @Override
             public void onClick(View v) {

                 // this is the Constraint for checking if all the red balls have been potted or not
                 if (red_ball == 15) {
                     red_ball_counter =1;
                     Toast.makeText(getApplicationContext(),"All Red are Potted!! No more Red please",Toast.LENGTH_SHORT).show();
                     Toast.makeText(getApplicationContext(),"Now Enter the Colored Balls",Toast.LENGTH_SHORT).show();
                 }
                 else if ( red_ball_counter == 0)

                 {

                 //  Red Ball get Incremented Here
                     red_ball += 1;
                     // below are the code that is going to change the individual Score of the Player for pressing the Red Ball
                     if (plrnumber == 1) {
                         score_P1T1 += 1;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 1;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 1;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 1;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 1;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 1;
                         team2_score.setText(String.valueOf(score_team2));
                     }

                 }
                 else if(red_ball == 15 && red_ball_counter == 1)
                 {
                     Toast.makeText(getApplicationContext(), "No More Red Ball Please !!", Toast.LENGTH_SHORT).show();
                 }
             }
         });
     }
     public void pink()
     {
         pink.setOnClickListener(new View.OnClickListener()
         {
             @Override
             public void onClick(View v) {
                 if (pink_ball ==1)
                 {
                     Toast.makeText(getApplicationContext() ," Invalid move !!",Toast.LENGTH_SHORT).show();
                 }
                 if (red_ball == 15 && pink_ball == 0) {
                     yellow_ball = 1;
                     green_ball = 1;
                     brown_ball = 1;
                     blue_ball = 1;
                     pink_ball = 1;
                     if (plrnumber == 1) {
                         score_P1T1 += 6;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 6;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 6;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 6;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 6;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 6;
                         team2_score.setText(String.valueOf(score_team2));
                     }


                 }

// below are the code that is going to change the individual Score of the Player for pressing the Red Ball
                 if (pink_ball == 0) {
                     if (plrnumber == 1) {
                         score_P1T1 += 6;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 6;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 6;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 6;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 6;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 6;
                         team2_score.setText(String.valueOf(score_team2));
                     }

                 }
             }


         });
     }
     public void blue()
     {
         blue.setOnClickListener(new View.OnClickListener()
         {
             @Override
             public void onClick(View v) {
                 if (blue_ball ==1)
                 {
                     Toast.makeText(getApplicationContext() ," Invalid move !!",Toast.LENGTH_SHORT).show();
                 }
                 if (red_ball == 15 && blue_ball == 0)

                 {
                     yellow_ball = 1;
                     green_ball = 1;
                     brown_ball = 1;
                     blue_ball = 1;
                     if (plrnumber == 1) {
                         score_P1T1 += 5;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 5;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 5;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 5;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 5;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 5;
                         team2_score.setText(String.valueOf(score_team2));
                     }

                 }
                 // below are the code that is going to change the individual Score of the Player for pressing the Blue Ball
                 if (blue_ball == 0) {
                     if (plrnumber == 1) {
                         score_P1T1 += 5;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 5;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 5;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 5;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 5;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 5;
                         team2_score.setText(String.valueOf(score_team2));
                     }
                 }
             }
         });
     }
     public void black()
     {
         black.setOnClickListener(new View.OnClickListener()
         {
             @Override
             public void onClick(View v) {
                 if (black_ball ==1)
                 {
                     Toast.makeText(getApplicationContext() ," Invalid move !!",Toast.LENGTH_SHORT).show();
                 }

                 if (red_ball == 15 && black_ball == 0)
                 {
                     yellow_ball =1;
                     green_ball = 1;
                     brown_ball =1;
                     blue_ball =1;
                     pink_ball =1;
                     black_ball =1;
                     if (plrnumber == 1) {
                         score_P1T1 += 7;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 7;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 7;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 7;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 7;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 7;
                         team2_score.setText(String.valueOf(score_team2));
                     }
                     // Game Over method id call to Show a toast message that game has ended
                     Game_Over();

                 }
                 // below are the code that is going to change the individual Score of the Player for pressing the Black Ball
                 if (black_ball == 0) {
                     if (plrnumber == 1) {
                         score_P1T1 += 7;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 7;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 7;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 7;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 7;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 7;
                         team2_score.setText(String.valueOf(score_team2));
                     }
                 }
             }


         });
     }
     public void brown()
     {
         brown.setOnClickListener(new View.OnClickListener()
         {
             @Override
             public void onClick(View v) {
                 if (brown_ball ==1)
                 {
                     Toast.makeText(getApplicationContext() ," Invalid move !!",Toast.LENGTH_SHORT).show();
                 }
                 if (red_ball == 15 && brown_ball == 0 )
                 {
                     yellow_ball =1;
                     green_ball =1;
                     brown_ball =1;
                     if (plrnumber == 1) {
                         score_P1T1 += 4;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 4;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 4;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 4;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 4;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 4;
                         team2_score.setText(String.valueOf(score_team2));
                     }


                 }
                 // below are the code that is going to change the individual Score of the Player for pressing the Brown Ball
                 if (brown_ball == 0)
                 {
                 if (plrnumber == 1) {
                     score_P1T1 += 4;
                     team1_player1_score.setText(String.valueOf(score_P1T1));
                 } else if (plrnumber == 2) {
                     score_P2T1 += 4;
                     team1_player2_score.setText(String.valueOf(score_P2T1));
                 } else if (plrnumber == 3) {
                     score_P1T2 += 4;
                     team2_player1_score.setText(String.valueOf(score_P1T2));
                 } else if (plrnumber == 4) {
                     score_P2T2 += 4;
                     team2_player2_score.setText(String.valueOf(score_P2T2));
                 }
                 // below are the code hat is going to add the Score to the Team total
                 if (plrnumber == 1 || plrnumber == 2) {
                     score_team1 += 4;
                     team1_score.setText(String.valueOf(score_team1));
                 } else if (plrnumber == 3 || plrnumber == 4) {
                     score_team2 += 4;
                     team2_score.setText(String.valueOf(score_team2));
                 }
             }
             }


         });
     }

     public void green()
     {
         green.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if (green_ball ==1)
                 {
                     Toast.makeText(getApplicationContext() ," Invalid move !!",Toast.LENGTH_SHORT).show();
                 }
                 if (red_ball == 15 && green_ball == 0) {
                     yellow_ball = 1;
                     green_ball = 1;

                     if (plrnumber == 1) {
                         score_P1T1 += 3;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 3;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 3;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 3;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 3;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 3;
                         team2_score.setText(String.valueOf(score_team2));
                     }

                 }

                 // below are the code that is going to change the individual Score of the Player for pressing the green Ball
                 if (green_ball == 0) {
                     if (plrnumber == 1) {
                         score_P1T1 += 3;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 3;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 3;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 3;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 3;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 3;
                         team2_score.setText(String.valueOf(score_team2));
                     }
                 }
             }

         });
     }
     public void yellow()
     {
         yellow.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 if (yellow_ball ==1)
                 {
                     Toast.makeText(getApplicationContext() ," Invalid move !!",Toast.LENGTH_SHORT).show();
                 }

                 if (red_ball == 15 && yellow_ball == 0) {
                     yellow_ball = 1;
                     if (plrnumber == 1) {
                         score_P1T1 += 2;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 2;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 2;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 2;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 2;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 2;
                         team2_score.setText(String.valueOf(score_team2));
                     }


                 }
                 // below are the code that is going to change the individual Score of the Player for pressing the yellow Ball
                 if (yellow_ball == 0) {
                     if (plrnumber == 1) {
                         score_P1T1 += 2;
                         team1_player1_score.setText(String.valueOf(score_P1T1));
                     } else if (plrnumber == 2) {
                         score_P2T1 += 2;
                         team1_player2_score.setText(String.valueOf(score_P2T1));
                     } else if (plrnumber == 3) {
                         score_P1T2 += 2;
                         team2_player1_score.setText(String.valueOf(score_P1T2));
                     } else if (plrnumber == 4) {
                         score_P2T2 += 2;
                         team2_player2_score.setText(String.valueOf(score_P2T2));
                     }
                     // below are the code hat is going to add the Score to the Team total
                     if (plrnumber == 1 || plrnumber == 2) {
                         score_team1 += 2;
                         team1_score.setText(String.valueOf(score_team1));
                     } else if (plrnumber == 3 || plrnumber == 4) {
                         score_team2 += 2;
                         team2_score.setText(String.valueOf(score_team2));
                     }
                 }
             }

         });
     }
     public void foul()
     {
         foul.setOnClickListener(new View.OnClickListener()
         {
             @Override
             public void onClick(View v)
             {
                 if (plrnumber == 1 || plrnumber == 2)
                 {
                     score_team2 += 4;
                     team2_score.setText(String.valueOf(score_team2));
                 }
                 else if ( plrnumber == 3 || plrnumber == 4)
                 {
                     score_team1 += 4;
                     team1_score.setText(String.valueOf(score_team1));
                 }

             }
         });
     }
     public void nextplayer()
     {
         next_plr.setOnClickListener(new View.OnClickListener()
         {
             @Override
             public void onClick(View v)
             {
          // this method is to make the player number between 1 to 4
              if (plrnumber >=4)
              {
                  plrnumber =1;

              }
              else if (plrnumber <=4)
              {
                  plrnumber += 1;
              }
                 player_number.setText(String.valueOf(plrnumber));

             }
         });
     }
}
